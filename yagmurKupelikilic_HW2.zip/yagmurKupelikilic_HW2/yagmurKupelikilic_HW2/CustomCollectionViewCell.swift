//
//  CustomCollectionViewCell.swift
//  yagmurKupelikilic_HW2
//
//  Created by CTIS Student on 2.05.2020.
//  Copyright © 2020 ctis. All rights reserved.
//

import UIKit

class CustomCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var cellLabel: UILabel!
    
    @IBOutlet weak var cellImageView: UIImageView!
    
    
}
