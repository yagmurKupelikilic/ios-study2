//
//  JsonVC.swift
//  yagmurKupelikilic_HW2
//
//  Created by CTIS Student on 28.04.2020.
//  Copyright © 2020 ctis. All rights reserved.
//

import UIKit

class JsonVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    let mDataSource = DataSource()
    @IBOutlet weak var mTableView: UITableView!
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return mDataSource.numberOfCategories()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mDataSource.numberOfItemsInEachCategory(index: section)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as UITableViewCell
       
           let records: [Record] = mDataSource.itemsInCategory(index: indexPath.section)
           
           let record = records[indexPath.row]
           
           cell.textLabel?.text = record.name
           cell.imageView?.image = UIImage(named: record.image)
           return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100.0
    }
 
     func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
         return 40.0
     }
     
     func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
         
         let label : UILabel = UILabel()
         
         label.text = mDataSource.getCategoryLabelAtIndex(index: section)
         label.font = UIFont(name: "HelveticaNeue-Bold", size: 20.0)
         label.textColor = #colorLiteral(red: 0.5807225108, green: 0.066734083, blue: 0, alpha: 1)
         label.textAlignment = NSTextAlignment.center
         label.backgroundColor = #colorLiteral(red: 0.9607843161, green: 0.7058823705, blue: 0.200000003, alpha: 1)
         
         return label
     }
     
     func getIndexPathForSelectedRow() -> IndexPath? {
         var indexPath: IndexPath?
         
         if mTableView.indexPathsForSelectedRows!.count > 0 {
             indexPath = mTableView.indexPathsForSelectedRows![0] as IndexPath
         }
         
         return indexPath
     }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
          
        if segue.identifier == "JsonDetailSegue"{

            if let indexPath = getIndexPathForSelectedRow() {
              
                let record = mDataSource.itemsInCategory(index:indexPath.section)[indexPath.row]
                
                let detailViewController = segue.destination as! DetailVC
                
                detailViewController.mReord = record
                print("selected image : " )
                print(record.name)
                                 
            }
        }
      }
    
   override func viewDidLoad() {
          super.viewDidLoad()
          mDataSource.populate(type: "json")
          title = "JSON"
      }
      

  
}

extension String {
    func removingWhitespaces() -> String {
        return components(separatedBy: .whitespaces).joined()
    }
}
