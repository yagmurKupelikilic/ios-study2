//
//  XmlVC.swift
//  yagmurKupelikilic_HW2
//
//  Created by CTIS Student on 28.04.2020.
//  Copyright © 2020 ctis. All rights reserved.
//

import UIKit

class XmlVC: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    
    let mDataSource = DataSource()
    
    @IBOutlet weak var mCollectionView: UICollectionView!
    
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return mDataSource.numberOfCategories()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return mDataSource.numberOfItemsInEachCategory(index: section)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CustomCollectionViewCell
     
        let records: [Record] = mDataSource.itemsInCategory(index: indexPath.section)
        
        let record = records[indexPath.row]
        
        cell.cellImageView.image = UIImage(named: record.image.lowercased())
        cell.cellLabel.text = record.name.capitalized
        return cell
    }
    
    
    
    
    // For each header setting the data
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        
        let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "header", for: indexPath) as! CustomCollectionReusableView
        
        headerView.headerLabel.text = mDataSource.getCategoryLabelAtIndex(index: indexPath.section)
        
        return headerView
    }
    
      override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
          
        if segue.identifier == "XmlSegue"{
              if let indexPath = getIndexPathForSelectedCell() {
                    
                    let record = mDataSource.itemsInCategory(index: indexPath.section)[indexPath.row]
                    
                    let mDetailVC = segue.destination as! DetailVC
                    
                    mDetailVC.mReord = record
                    print("")
                    print("selected image : " )
                    print(record.name)
                  
                }
          }
        
      }
    
       // Our function to find the indexPath of selected cell
       func getIndexPathForSelectedCell() -> IndexPath? {
           var indexPath: IndexPath?
           
           if mCollectionView.indexPathsForSelectedItems!.count > 0 {
               indexPath = mCollectionView.indexPathsForSelectedItems![0] as IndexPath
           }
         
           return indexPath
       }
    
    override func viewDidLoad() {
        super.viewDidLoad()
           mDataSource.populate(type: "xml")
        //print(mDataSource.mRecordList)
           title = "XML"
    }
    
    
}
