//
//  CustomCollectionReusableView.swift
//  yagmurKupelikilic_HW2
//
//  Created by CTIS Student on 2.05.2020.
//  Copyright © 2020 ctis. All rights reserved.
//

import UIKit

class CustomCollectionReusableView: UICollectionViewCell {
    
    @IBOutlet weak var headerLabel: UILabel!
}
