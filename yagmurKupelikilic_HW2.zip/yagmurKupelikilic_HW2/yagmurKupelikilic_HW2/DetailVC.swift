//
//  DetailVC.swift
//  yagmurKupelikilic_HW2
//
//  Created by CTIS Student on 28.04.2020.
//  Copyright © 2020 ctis. All rights reserved.
//

import UIKit

class DetailVC: UIViewController {

    var mReord: Record?
    
    
    @IBOutlet weak var mImageView: UIImageView!
    @IBOutlet weak var mTextView: UITextView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
           if let record = mReord {
               
            navigationItem.title = record.name.capitalized
        
            mImageView.image = UIImage(named: record.image.lowercased())
            mTextView.text = record.description
           
        }
      
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
